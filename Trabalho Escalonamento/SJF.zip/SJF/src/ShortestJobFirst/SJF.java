package ShortestJobFirst;

import java.util.Scanner;


/**
 * 
 * O SJF (Shortest Job First ou Processo mais curto primeiro) � um algoritmo de escalonamento que executa, dentre processos igualmente importantes, o mais curto primeiro.
 * 
 *
 */
 
public class SJF {
	
    public static void main(String args[])
    {
        int process[] = new int[10];
        int ptime[] = new int[10];
        int wtime[] = new int[10];
        int temp, n, total=0;
        float avg=0;
        Scanner get = new Scanner(System.in);
 
        System.out.println("Entre com o Numero de Processos:");
        n = get.nextInt();
        for(int i=0;i<n;i++)
        {
            System.out.println("Entre com o "+(i+1)+" ID: ");
            process[i] = get.nextInt();
            System.out.println("Entre com o "+(i+1)+" Burst Time: ");
            ptime[i] = get.nextInt();
        }
 
        for(int i=0;i<n-1;i++)
        {
            for(int j=i+1;j<n;j++)           {               if(ptime[i]>ptime[j])
                {
                    temp = ptime[i];
                    ptime[i] = ptime[j];
                    ptime[j] = temp;
                    temp = process[i];
                    process[i] = process[j];
                    process[j] = temp;
                }
            }
        }
 
        wtime[0] = 0;
        for(int i=1;i<n;i++)
        {
            wtime[i] = wtime[i-1]+ptime[i-1];
            total = total + wtime[i];
        }
        avg = (float)total/n;
        System.out.println("P_ID P_TIME W_TIME");
        for(int i=0;i<n;i++)
        {
            System.out.println(process[i]+"\t"+ptime[i]+"\t"+wtime[i]);
        }
        System.out.println("Tempo total de espera: "+total);
        System.out.println("Tempo medio de espera: "+avg);
    }
}